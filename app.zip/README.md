# A python application for an I.S.P Company that promotes the business
